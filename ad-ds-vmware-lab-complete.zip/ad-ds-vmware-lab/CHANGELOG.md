# Changelog

All significant project updates will be recorded here.

## [1.0.0] - 2026-08-08

### Completed

- Declared the AD DS VMware home lab complete within its defined single-domain-controller scope.
- Finalized Windows Server deployment, forest creation, DNS, client domain join, identity administration, Group Policy, AGDLP file access, domain security policy, recovery, and troubleshooting documentation.
- Removed the second domain controller and replication phase from the active roadmap.
- Retained account-lockout and password-minimum enforcement tests as optional future practice rather than incomplete project requirements.
- Updated the README, architecture, validation checklist, and Lab 08 status to match the completed project scope.
- Expanded the portfolio README with a complete topic inventory covering virtualization, networking, AD DS, DNS, domain joining, computer lifecycle, account administration, SIDs, access tokens, AGDLP, Group Policy, file authorization, domain security policy, recovery, and troubleshooting.

## [Unreleased]

### Added

- Initial portfolio README.
- Lab 00 planning and prerequisite documentation.
- Preliminary architecture and design principles.
- Validation checklist.
- Troubleshooting incident template.
- Screenshot privacy and naming standards.
- Lab 01 Windows Server 2022 VM deployment guide with interview revision questions.
- Sanitized PowerShell validation evidence for the completed Windows Server deployment.
- Lab 03 guide covering AD DS role installation, forest promotion, AD-integrated DNS, validation, recovery, and interview preparation.
- Troubleshooting records for missing DNS zones and a stale Public network profile.
- Sanitized evidence showing the corrected domain, DNS zones, locator records, DC discovery, and DomainAuthenticated profile.
- Lab 04 guide covering client inspection, naming, AD DNS, domain join, computer-account validation, secure-channel validation, prestaging, and the first domain-user login.
- Lab 05 guide covering local-access validation, domain removal, stale-object analysis, Workstations OU design, manual prestaging, rejoin, and first GPO configuration.
- Lab 06 guide covering user provisioning, role groups, password reset, account disable/enable, GPO validation, and rollback.
- Lab 07 guide covering IT and HR SMB shares, AGDLP authorization, NTFS/share permissions, and positive and negative access tests.
- Lab 08 guide covering the Default Domain Policy backup, password-policy review, and account-lockout configuration.

### Verified

- Confirmed that the existing client virtual machine runs Windows 11 Pro and supports an AD DS domain join.
- Recorded the physical host's CPU, memory, and available-storage capacity.
- Recorded a clean host baseline of 7.02 GB available memory and 136.36 GB free storage after workload cleanup.
- Installed Windows Server 2022 Standard Evaluation with Desktop Experience.
- Verified 4 GB RAM, 2 logical processors, a 59.37 GB system disk, running VMware Tools, and UEFI Secure Boot.
- Created the powered-off baseline snapshot `01 - Windows Server 2022 Clean Install`.
- Created and used `02 - DC01 Pre-AD DS Configuration` as a recovery checkpoint.
- Installed AD DS and created the `northstar.example.com` forest with NetBIOS name `NORTHSTAR`.
- Verified the domain and `_msdcs` zones as AD-integrated.
- Verified the LDAP SRV record, `DC01` host record, and DC Locator response.
- Corrected the stale Public profile and verified `DomainAuthenticated`.
- Created snapshot `03 - AD DS Forest Healthy` before beginning the client domain-join phase.
- Corrected the documented client operating system from Windows 11 to the detected Windows 10 Pro installation.
- Renamed the client to `CLIENT01`, configured AD DNS, and joined `northstar.example.com`.
- Verified the CLIENT01 computer account and secure channel.
- Created and successfully authenticated the first domain user on CLIENT01.
- Confirmed the client is Windows 11 Pro 25H2 and corrected the compatibility-reported Windows 10 label.
- Created `04 - CLIENT01 Domain Joined Baseline` before the computer lifecycle exercise.
- Removed CLIENT01 from the domain, observed and deleted the stale enabled AD object, and verified local access.
- Created `Northstar\Workstations`, manually prestaged CLIENT01, verified AD DNS, and rejoined the workstation.
- Created and linked `Northstar - Users - Disable Control Panel` and refreshed Group Policy on the target user.
- Removed the Control Panel GPO link and confirmed that the restriction was rolled back.
- Reset a standard domain-user password and confirmed successful authentication.
- Disabled the same account and confirmed that CLIENT01 rejected a new sign-in, then re-enabled the account.
- Implemented and validated AGDLP for the IT Modify and HR Read shares.
- Backed up the Default Domain Policy before making a domain-wide security change.
- Increased the domain minimum password length from 7 to 8 characters.
- Configured a five-attempt lockout threshold with a ten-minute duration and reset interval.

### Changed

- Added a resource plan of 2 vCPUs and 4 GB RAM for each lab VM.
- Added an operational note to close unnecessary applications when both VMs are running.
- Retained 4 GB as the initial `DC01` memory allocation with a documented 3 GB fallback if host performance becomes unacceptable.
- Changed the planned `DC01` operating system from Windows Server 2025 to Windows Server 2022 to use the installation media already available.
- Marked Lab 01 complete and documented the full VM creation, operating-system installation, troubleshooting, and validation procedure.
- Added the IACP interview-memory framework, networking design, static-IP configuration, time validation, update procedure, and command-learning strategy to Lab 02.
- Marked planning, networking, server preparation, and forest deployment complete.
- Corrected the lab forest design from the unsuccessful `northstar.example` deployment to `northstar.example.com`.
