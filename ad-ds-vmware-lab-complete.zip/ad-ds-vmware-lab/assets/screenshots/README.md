# Screenshot Evidence

Sanitized screenshots will be organized by lab phase in this directory.

Images must follow the requirements in [`docs/screenshot-standards.md`](../../docs/screenshot-standards.md).

