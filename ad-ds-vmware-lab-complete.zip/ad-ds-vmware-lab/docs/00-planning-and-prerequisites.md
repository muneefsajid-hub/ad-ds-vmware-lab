# Lab 00 - Planning and Prerequisites

## Objective

Prepare a recoverable VMware environment for deploying Active Directory Domain Services without modifying a production network or relying on the existing Windows 11 virtual machine as a server.

## Learning outcomes

After completing this phase, I will be able to:

- explain the purpose of each virtual machine;
- distinguish a domain controller from a client workstation;
- verify whether a Windows client edition supports domain joining;
- estimate safe virtual CPU, memory, and storage allocations;
- create a VMware snapshot before a major configuration change; and
- explain why lab credentials and personal information must not appear in a public repository.

## Prerequisite inventory

| Requirement | Planned value | Verified |
|---|---|:---:|
| Hypervisor | VMware Workstation Pro | ✅ |
| Existing client VM | Windows 11 | ✅ |
| Windows 11 edition | Windows 11 Pro | ✅ |
| Host memory | 15.73 GB installed; 7.02 GB available after closing the client VM and unnecessary browser tabs | ✅ |
| Host CPU | 4 physical cores; 8 logical processors | ✅ |
| Available host storage | 136.36 GB free on drive C: | ✅ |
| Client recovery snapshot | `Before AD DS Lab` | ⬜ |
| Server installation media | Existing Windows Server 2022 ISO | ✅ |

## Design rationale

### Separate server and client systems

AD DS will run on a dedicated Windows Server virtual machine named `DC01`. The existing Windows 11 virtual machine will become `CLIENT01`. Separating these roles reflects common enterprise architecture and allows domain authentication and client-management workflows to be tested realistically.

### Recovery before change

A powered-off VMware snapshot will be created before the Windows 11 VM joins the domain. The snapshot provides a convenient lab rollback point. It is not treated as a substitute for a proper backup.

### Network isolation

The environment will use a controlled VMware virtual network. The final network mode and address range will be selected after inspecting VMware's Virtual Network Editor. Isolation reduces the chance that unfinished DHCP, DNS, or routing configurations will interfere with the physical home network.

## Procedure

### 1. Confirm the Windows 11 edition

Inside the Windows 11 VM:

1. Press `Windows + R`.
2. Run `winver`.
3. Record the displayed edition.

Windows 11 Pro, Enterprise, and Education can join an AD DS domain. Windows 11 Home cannot serve as the planned domain client without an edition upgrade.

**Observed result:** The existing client VM is running Windows 11 Pro and is suitable for joining the planned AD DS domain.

### 2. Record host resources

On the physical Windows host:

1. Open Task Manager.
2. Select **Performance**.
3. Record total memory and logical processors.
4. Open **This PC** and record available storage on the VMware drive.

Do not publish the physical computer's serial number, Windows product key, personal device name, or unrelated account information.

**Observed host resources:**

| Resource | Observed value |
|---|---:|
| Installed memory | 15.73 GB |
| Available memory before workload cleanup | 2.13 GB |
| Available memory after workload cleanup | 7.02 GB |
| Physical CPU cores | 4 |
| Logical processors | 8 |
| Free storage on drive C: | 136.36 GB |

The available-memory reading increased by 4.89 GB after shutting down the Windows 11 VM and closing unnecessary browser tabs. This confirms that workload management materially affects the host's ability to run the lab. Heavy applications and unused VMs will be closed before both lab machines are started.

### Planned virtual-machine allocation

| Virtual machine | Virtual CPUs | Memory | Maximum virtual disk |
|---|---:|---:|---:|
| `DC01` | 2 | 4 GB | 60 GB, dynamically expanding |
| `CLIENT01` | 2 | 4 GB | Existing virtual disk |

Using two virtual CPUs per VM avoids oversubscribing the four-core host during ordinary lab exercises. A 4 GB memory allocation provides a workable graphical Windows Server lab while retaining capacity for the host operating system.

If the physical host becomes consistently sluggish while both VMs are active, `DC01` may be reduced to 3 GB after a clean shutdown. The 4 GB allocation remains the starting configuration.

### 3. Create the client recovery snapshot

1. Shut down the Windows 11 VM.
2. In VMware Workstation Pro, select **VM > Snapshot > Take Snapshot**.
3. Use the name `Before AD DS Lab`.
4. Add the description:

   > Windows 11 standalone configuration before joining the Northstar domain.

## Evidence to capture

| Evidence ID | Screenshot | Publication status |
|---|---|---|
| E00-01 | Windows 11 edition shown in `winver` | Sanitize before publishing |
| E00-02 | VMware snapshot manager showing the recovery snapshot | Sanitize before publishing |
| E00-03 | Host resource summary | Record values in text; do not publish unnecessary device details |

Place approved images in `assets/screenshots/00-planning/`.

## Validation

- [x] The Windows 11 edition supports an AD DS domain join.
- [x] Host resources can support both VMs simultaneously when unnecessary applications and VMs are closed.
- [x] Sufficient storage exists for the Windows Server VM.
- [ ] The Windows 11 VM is fully powered off before snapshot creation.
- [ ] The snapshot appears in VMware Snapshot Manager.
- [ ] No secrets or personally identifying information are included in evidence.

## Reflection

This phase demonstrates that infrastructure work begins with requirements, risk reduction, capacity planning, and documentation rather than immediately installing software.

## Sources

- [Microsoft: Active Directory Domain Services overview](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/virtual-dc/active-directory-domain-services-overview)
- [Microsoft: Windows Server 2022 Evaluation](https://www.microsoft.com/en-us/evalcenter/evaluate-windows-server-2022)
- [Broadcom: Host-only networking in VMware Workstation Pro](https://techdocs.broadcom.com/us/en/vmware-cis/desktop-hypervisors/workstation-pro/17-0/using-vmware-workstation-pro/configuring-network-connections/configuring-host-only-networking.html)
