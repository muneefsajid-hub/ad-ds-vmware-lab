# Lab 01 - Deploying the Windows Server 2022 VM

## Status

**Complete — validated July 23, 2026**

## Objective

Create and validate a Windows Server 2022 virtual machine named `DC01` in VMware Workstation Pro. The VM will later become the first domain controller and DNS server for the Northstar Technologies lab.

## Learning outcomes

This lab demonstrates the ability to:

- create a custom virtual machine with deliberate hardware choices;
- perform a clean Windows Server installation;
- distinguish Server Core from Desktop Experience;
- install VMware Tools;
- validate an installation with PowerShell; and
- explain configuration decisions during an interview.

## Final configuration

| Setting | Selected value | Reason |
|---|---|---|
| VMware object name | `DC01` | Identifies the VM's intended role |
| VM location | `C:\Virtual Machines\DC01` | Keeps VM files outside OneDrive synchronization |
| Compatibility | Workstation 17.5 or later | Matches the installed hypervisor |
| Guest OS | Windows Server 2022 | Supports the planned AD DS lab |
| Edition | Standard Evaluation (Desktop Experience) | Provides the GUI used in the learning labs |
| Firmware | UEFI with Secure Boot | Uses a modern, validated boot configuration |
| CPU | 1 processor, 2 cores | Avoids unnecessary virtual sockets and fits the host |
| Memory | 4 GB | Practical allocation for the graphical lab |
| Network | NAT | Provides initial connectivity through the host |
| SCSI controller | LSI Logic SAS | VMware's recommended controller for this guest |
| System disk | NVMe, 60 GB | Modern virtual-disk interface and adequate lab capacity |
| Disk allocation | Growable, single file | Conserves host space while keeping storage simple |
| Installation media | Windows Server 2022 Evaluation ISO | Available legitimate evaluation media |

> The VMware object is named `DC01`, but Windows initially generated the computer name `WIN-6246MF2TQ4G`. Renaming the operating system is a separate post-installation task.

## Procedure

### 1. Create a custom VM

1. In VMware Workstation Pro, select **File > New Virtual Machine**.
2. Select **Custom (advanced)**.
3. Keep **Workstation 17.5 or later** for hardware compatibility.
4. Select **I will install the operating system later** to retain manual control of setup.
5. Select **Microsoft Windows** and **Windows Server 2022**.

The custom workflow exposed the firmware, processor, memory, network, controller, and disk choices required for a reproducible build.

### 2. Name and store the VM

1. Set the virtual-machine name to `DC01`.
2. Set the location to `C:\Virtual Machines\DC01`.

The first attempted location was inside a OneDrive-managed Documents folder. It was changed because live VM files are large, change frequently, and should not be synchronized by consumer file-sync software.

### 3. Configure virtual hardware

1. Select **UEFI** and enable **Secure Boot**.
2. Configure **1 processor** with **2 cores per processor**.
3. Allocate **4096 MB** of memory.
4. Select **Use network address translation (NAT)**.
5. Keep **LSI Logic SAS** as the SCSI controller.
6. Select **NVMe** as the virtual disk type.
7. Create a new 60 GB virtual disk.
8. Leave **Allocate all disk space now** cleared so the disk grows as data is added.
9. Select **Store virtual disk as a single file**.
10. Keep the default disk filename, `DC01.vmdk`.

One virtual socket with two cores is preferable to two one-core sockets in this lab because it presents a simpler topology and avoids unnecessary socket-based licensing or scheduling considerations.

### 4. Attach the ISO

The VM was accidentally finished before the ISO was attached. This did not require rebuilding it:

1. Open **VM > Settings** while the VM is powered off.
2. Select **CD/DVD (SATA)**.
3. Select **Use ISO image file** and browse to the Windows Server 2022 ISO.
4. Enable **Connect at power on**.

VMware `.lck` directories appeared while the VM was open. These are normal lock files used to protect an active VM and should not be manually deleted while VMware is using it.

### 5. Install Windows Server

1. Power on the VM and start **Windows Setup [EMS Enabled]**.
2. Confirm the language, time/currency format, and keyboard layout.
3. Select **Install now**.
4. Choose **Windows Server 2022 Standard Evaluation (Desktop Experience)**.
5. Accept the evaluation license terms.
6. Select **Custom: Install Microsoft Server Operating System only (advanced)**.
7. Select **Drive 0 Unallocated Space (60 GB)** and continue.
8. Allow Setup to create the required partitions, copy files, and restart.

Desktop Experience was chosen for this first course volume because its graphical tools make AD DS components easier to observe. Server Core has a smaller attack surface and servicing footprint, but relies more heavily on remote administration and the command line.

### 6. Secure the local Administrator account

At the first-start screen, a strong private password was created for the built-in `Administrator` account.

Passwords, password hints, recovery information, product keys, and authentication screens must never be committed to the repository or exposed in screenshots.

### 7. Complete initial setup

1. Sign in as the local Administrator.
2. Select **No** when asked whether the server should be discoverable on the current NAT network. This can be revisited when the isolated lab network is designed.
3. Dismiss the optional Windows Admin Center information prompt.

### 8. Install VMware Tools

1. In VMware Workstation, choose **VM > Install VMware Tools**.
2. Open the mounted VMware Tools DVD inside the guest.
3. Run the installer and choose **Typical**.
4. Restart the guest when prompted.

VMware Tools supplies guest integration components and drivers. The running service was later verified through PowerShell.

## Validation

The following PowerShell was run as Administrator:

```powershell
$computer = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$vmTools = Get-Service VMTools -ErrorAction SilentlyContinue
$secureBoot = Confirm-SecureBootUEFI

[PSCustomObject]@{
    "Computer Name"       = $env:COMPUTERNAME
    "Operating System"    = $os.Caption
    "OS Version"          = $os.Version
    "Installed RAM (GB)"  = [math]::Round($computer.TotalPhysicalMemory / 1GB, 2)
    "Logical Processors"  = $computer.NumberOfLogicalProcessors
    "C Drive Size (GB)"   = [math]::Round($disk.Size / 1GB, 2)
    "C Drive Free (GB)"   = [math]::Round($disk.FreeSpace / 1GB, 2)
    "VMware Tools Status" = if ($vmTools) { $vmTools.Status } else { "Not found" }
    "Secure Boot"         = $secureBoot
}
```

### Observed results

| Control | Observed result | Status |
|---|---|---|
| Operating system | Microsoft Windows Server 2022 Standard Evaluation | Passed |
| OS version | 10.0.20348 | Passed |
| Installed memory | 4 GB | Passed |
| Logical processors | 2 | Passed |
| System disk | 59.37 GB, 48.52 GB free | Passed |
| VMware Tools | Running | Passed |
| Secure Boot | True | Passed |

### Evidence

![Sanitized Windows Server deployment validation](../assets/screenshots/01-server-deployment/01-15-installation-validation.png)

The automatically generated computer name in this screenshot is temporary and contains no credential. It will be replaced with `DC01` before AD DS is installed.

## Troubleshooting and lessons learned

| Observation | Cause or interpretation | Resolution |
|---|---|---|
| VM was initially placed under OneDrive | Default VMware location inherited the synchronized Documents path | Changed the VM path to `C:\Virtual Machines\DC01` |
| Wizard was finished before ISO selection | Manual installation intentionally created a blank VM | Attached the ISO afterward through VM settings |
| Two `.lck` folders appeared | VMware created active lock directories | Left them untouched and closed VMware before any cleanup |
| Guest screenshots would not paste to the host | Clipboard integration is not a dependable image-transfer workflow | Used the host Snipping Tool while the VM console was visible |
| Windows name differs from VM name | VMware inventory names do not rename the guest OS | Scheduled a Windows computer rename for the next lab |

## Interview revision

### Why use Custom instead of Typical?

Custom configuration made compatibility, firmware, CPU topology, memory, networking, controllers, and disk allocation explicit. That improved control and made the deployment reproducible.

### Why use Desktop Experience?

Desktop Experience provides local graphical administration tools, which are useful while learning AD DS. In production, Server Core may be preferable when application compatibility and the administration model permit it.

### Why was NAT selected initially?

NAT gives the guest outbound connectivity through the host without placing it directly on the physical LAN. The final AD DS network will be reviewed separately because domain clients must use the domain controller for DNS.

### What is the difference between the VMware VM name and Windows computer name?

The VMware name identifies the virtual machine in the hypervisor inventory. The Windows computer name identifies the operating-system instance on the network and in Active Directory. Changing one does not automatically change the other.

### Why install VMware Tools?

VMware Tools improves guest integration and provides optimized drivers and services. Its service state also supplies a useful validation point for the deployment.

### Why take a clean-install snapshot?

A powered-off snapshot provides a recovery point before identity, DNS, and networking changes are introduced. It supports repeatable experimentation but does not replace an independent backup.

## Completion checklist

- [x] Custom VM created outside OneDrive.
- [x] Windows Server 2022 Standard Evaluation (Desktop Experience) installed.
- [x] 2 vCPUs, 4 GB RAM, and a 60 GB virtual disk verified.
- [x] UEFI Secure Boot verified.
- [x] VMware Tools installed and running.
- [x] Sanitized evidence captured.
- [x] No password, product key, or recovery secret documented.
- [x] Powered-off snapshot `01 - Windows Server 2022 Clean Install` created.
- [ ] Windows computer renamed to `DC01`.

## Sources

- [Microsoft Evaluation Center: Windows Server 2022](https://www.microsoft.com/en-us/evalcenter/evaluate-windows-server-2022)
- [Microsoft Learn: Windows Server installation guidance](https://learn.microsoft.com/en-us/windows-server/get-started/install-windows-server)
- [Microsoft Learn: Secure Boot and Trusted Boot](https://learn.microsoft.com/en-us/windows/security/operating-system-security/system-security/secure-the-windows-10-boot-process)
- [Broadcom: Installing VMware Tools](https://knowledge.broadcom.com/external/article/315363/installing-vmware-tools-in-a-windows-vir.html)
- [Broadcom: Understanding virtual machine files](https://knowledge.broadcom.com/external/article/320240/understanding-the-files-that-make-up-a-v.html)
