# Lab 02 - Preparing DC01

## Status

**Complete**

## Objective

Prepare the Windows Server 2022 guest for its future AD DS and DNS roles. This phase covers the Windows computer name, time, updates, virtual networking, static addressing, and validation before domain-controller promotion.

## Change sequence

1. Rename the Windows computer to `DC01`.
2. Confirm the restart and validate the new name.
3. Review time, time zone, and pending updates.
4. Design the isolated VMware lab network.
5. Assign and validate a static IPv4 configuration.
6. Create a post-installation snapshot.

## Step 1 - Rename the Windows computer

The VMware inventory name and Windows computer name are separate. The VM is already named `DC01`, but the guest operating system still has an automatically generated name.

Open **Windows PowerShell as Administrator**, then run:

```powershell
Rename-Computer -NewName "DC01" -Restart
```

The server will restart automatically.

### Validation after restart

Sign back in with the local Administrator account, open PowerShell, and run:

```powershell
hostname
Get-ComputerInfo -Property CsName, WindowsProductName, WindowsVersion
```

The expected `CsName` and `hostname` result is:

```text
DC01
```

### Why the rename happens before AD DS promotion

A domain controller's computer name becomes part of its identity and DNS records. Assigning the intended name before promotion avoids an unnecessary domain-controller rename later.

### Interview revision

**Why does renaming the VM in VMware not rename Windows?**

The VMware inventory name identifies the VM to the hypervisor. The computer name is maintained inside Windows and is used by Windows networking, DNS, and Active Directory.

**Why is a restart required?**

Windows must restart to complete the computer-name change so services and the operating system consistently use the new identity.

## Step 2 - Inspect the VMware NAT network

`Get-NetIPConfiguration` showed that the DHCP-assigned configuration used:

| Setting | Observed value |
|---|---|
| Interface | `Ethernet0` |
| IPv4 address | `192.168.183.130` |
| Prefix length | `/24` |
| Default gateway | `192.168.183.2` |
| DNS server | `192.168.183.2` |

The VMware Virtual Network Editor confirmed that `VMnet8` uses NAT on `192.168.183.0/24`. Its DHCP pool is `192.168.183.128` through `192.168.183.254`.

The proposed address `192.168.183.10` was tested before assignment:

```powershell
Test-Connection -ComputerName 192.168.183.10 -Count 2 -Quiet
```

The result was `False`, indicating that no device responded at that address in the controlled lab. The address is also outside the DHCP pool, reducing the risk of VMware leasing it to another guest.

### Evidence

![Initial DHCP configuration](../assets/screenshots/02-dc01-preparation/02-01-initial-dhcp-configuration.png)

![VMnet8 subnet configuration](../assets/screenshots/02-dc01-preparation/02-02-vmnet8-subnet.png)

![VMnet8 DHCP range](../assets/screenshots/02-dc01-preparation/02-03-vmnet8-dhcp-range.png)

## Step 3 - Assign and validate a static IPv4 address

The following commands assigned the selected address and temporarily retained VMware NAT DNS:

```powershell
New-NetIPAddress `
    -InterfaceAlias "Ethernet0" `
    -IPAddress "192.168.183.10" `
    -PrefixLength 24 `
    -DefaultGateway "192.168.183.2"

Set-DnsClientServerAddress `
    -InterfaceAlias "Ethernet0" `
    -ServerAddresses "192.168.183.2"
```

Connectivity was checked with:

```powershell
Test-Connection 192.168.183.2 -Count 2
Test-NetConnection www.microsoft.com -Port 443
```

`Test-NetConnection` reported:

- source address `192.168.183.10`;
- successful DNS name resolution; and
- `TcpTestSucceeded: True` for HTTPS on TCP port 443.

`PingSucceeded: False` for the public destination did not represent a failure because the TCP 443 test succeeded; public services may decline ICMP echo requests while continuing to provide HTTPS.

![Static IP and HTTPS connectivity validation](../assets/screenshots/02-dc01-preparation/02-04-static-ip-connectivity.png)

## Step 4 - Correct and validate time

The server initially used `Pacific Standard Time`. It was corrected for the lab's location:

```powershell
Set-TimeZone -Id "Eastern Standard Time"
w32tm /resync
```

Validation:

```powershell
Get-TimeZone
Get-Date
w32tm /query /status
```

The completed test showed `Eastern Standard Time`, no leap warning, successful synchronization, and `time.windows.com` as the current source.

Accurate time is important because Active Directory uses Kerberos authentication, which relies on closely synchronized clocks. After promotion, the domain will establish a Windows domain time hierarchy.

![Eastern time zone and Windows Time validation](../assets/screenshots/02-dc01-preparation/02-05-time-validation.png)

## Step 5 - Install Windows updates

Windows Update was run repeatedly until required updates were installed. The server was restarted as requested and the following items were reconfirmed:

- hostname remained `DC01`;
- static address remained `192.168.183.10`; and
- recently installed hotfixes were present.

Preview updates, unnecessary language packs, and unrelated optional drivers were not required for this baseline.

## Memory framework - IACP

The preparation sequence can be remembered as **IACP: Identity, Address, Clock, Patches**.

| Preparation | Lab action | Why it matters to AD DS |
|---|---|---|
| **Identity** | Renamed Windows to `DC01` | The domain controller needs a permanent, meaningful identity |
| **Address** | Assigned `192.168.183.10` | DNS and clients must consistently locate the domain controller |
| **Clock** | Corrected the time zone and synchronized time | Kerberos authentication depends on accurate time |
| **Patches** | Installed Windows updates | The server should be secure and stable before receiving an infrastructure role |

### Office-building analogy

- The **computer name** is the building's permanent name.
- The **static IP address** is its permanent street address.
- **DNS** is the company directory that tells users where services are located.
- **Time synchronization** is the shared clock used to validate security passes.
- **Updates** are repairs completed before employees move into the building.

## Configuration reference

```text
Server name:       DC01
Static IP:         192.168.183.10
Network:           192.168.183.0/24
Subnet mask:       255.255.255.0
Gateway:           192.168.183.2
VMware DHCP pool:  192.168.183.128-192.168.183.254
Pre-promotion DNS: 192.168.183.2 (temporary)
Post-promotion DNS:192.168.183.10
Time zone:         Eastern Standard Time
```

The VMware NAT DNS value was temporary. After promotion, `DC01` was configured to query its own AD-integrated DNS service at `192.168.183.10`.

## Command-learning strategy

Administrators do not need to memorize every parameter. The priority is understanding the desired state, selecting the appropriate command, reviewing its syntax, and validating the result.

```powershell
# Discover current networking
Get-NetIPConfiguration

# Configure an address
New-NetIPAddress

# Configure DNS
Set-DnsClientServerAddress

# Test connectivity
Test-NetConnection

# Retrieve syntax and examples when needed
Get-Help New-NetIPAddress -Examples
```

## Technical Competencies Demonstrated

> Before installing Active Directory Domain Services, I prepared the Windows Server by assigning the permanent hostname `DC01`, configuring a static IPv4 address, validating gateway and DNS connectivity, correcting the time zone, confirming time synchronization, and installing Windows updates. A domain controller requires a stable identity and network address because clients locate AD services through DNS. Accurate time is required for Kerberos authentication, and patching reduces security and reliability risks before the server receives a critical infrastructure role.

Interviewers generally expect the candidate to explain the purpose, sequence, validation, and troubleshooting—not recite every PowerShell parameter from memory.

## Safety notes

- Do not rename the server after promoting it unless there is a justified change plan.
- Do not expose the Administrator password in screenshots or command history.
- Take a pre-promotion snapshot before installing AD DS so the lab can be safely rebuilt if promotion fails.

## Sources

- [Microsoft Learn: Rename-Computer](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/rename-computer)
- [Microsoft Learn: Naming conventions in Active Directory](https://learn.microsoft.com/en-us/troubleshoot/windows-server/active-directory/naming-conventions-for-computer-domain-site-ou)
- [Microsoft Learn: Get-Help](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/get-help)
- [Microsoft Learn: New-NetIPAddress](https://learn.microsoft.com/en-us/powershell/module/nettcpip/new-netipaddress)
- [Microsoft Learn: Set-DnsClientServerAddress](https://learn.microsoft.com/en-us/powershell/module/dnsclient/set-dnsclientserveraddress)
- [Microsoft Learn: Windows Time service](https://learn.microsoft.com/en-us/windows-server/networking/windows-time-service/windows-time-service-top)
- [Microsoft Learn: Kerberos authentication overview](https://learn.microsoft.com/en-us/windows-server/security/kerberos/kerberos-authentication-overview)
- [Microsoft Learn: Reviewing DNS concepts for AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/reviewing-dns-concepts)
