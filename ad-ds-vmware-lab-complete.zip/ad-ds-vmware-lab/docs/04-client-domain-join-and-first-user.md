# Lab 04 - Joining CLIENT01 and Testing a Domain User

## Status

**Complete**

## Objective

Prepare a Windows client, join it to `northstar.example.com`, validate its computer account and secure channel, create a domain user, and prove that centralized authentication works.

## Important discovery

An initial compatibility-facing PowerShell property reported:

```text
Windows 10 Pro
```

Windows Settings later provided the authoritative edition and build:

```text
Windows 11 Pro
Version 25H2
OS build 26200.8875
```

Some compatibility-facing Windows properties can retain Windows 10 naming on Windows 11. The client documentation was corrected to Windows 11 Pro.

## Final client configuration

| Setting | Value |
|---|---|
| Computer name | `CLIENT01` |
| Operating system | Windows 11 Pro 25H2 |
| Initial DHCP address | `192.168.183.128` |
| Default gateway | `192.168.183.2` |
| DNS server after preparation | `192.168.183.10` (`DC01`) |
| Domain | `northstar.example.com` |
| Computer account | `CLIENT01` |
| Secure channel | Valid |

## Plain-English model

Before the join, CLIENT01 was an independent computer. It trusted only accounts stored in its own local account database.

After the join:

- DNS tells CLIENT01 where the Northstar domain controller is;
- DC01 stores a computer identity for CLIENT01;
- CLIENT01 and DC01 maintain a secure machine-account relationship;
- users stored in Active Directory can authenticate on CLIENT01; and
- domain policies and permissions can later manage the client.

Think of DC01 as a company's security office, DNS as the company directory, the computer account as CLIENT01's registered device badge, and the domain user as an employee identity.

## Step 1 - Inspect the client baseline

The following commands were run from Administrator PowerShell on the client:

```powershell
hostname

Get-ComputerInfo `
    -Property CsName, WindowsProductName, WindowsVersion

Get-NetIPConfiguration |
    Select-Object InterfaceAlias, IPv4Address, IPv4DefaultGateway, DNSServer

Get-WindowsEdition -Online
```

The baseline showed hostname `MUNEEF-PC`, a compatibility-reported `Windows 10 Pro` product string, and DHCP address `192.168.183.128` on VMnet8. Windows Settings later confirmed Windows 11 Pro 25H2.

![CLIENT01 baseline before rename](../assets/screenshots/04-client-domain-join/04-01-client-baseline.png)

## Step 2 - Rename the workstation

```powershell
Rename-Computer -NewName "CLIENT01" -Restart
```

The original computer name could have worked technically. `CLIENT01` was selected because it:

- identifies the machine's role;
- matches the `DC01` naming pattern;
- supports future names such as `CLIENT02`;
- makes troubleshooting and inventory clearer; and
- avoids exposing a personal name in public documentation.

The rename was completed before joining so Active Directory would receive the intended computer identity.

## Step 3 - Configure AD DNS

CLIENT01 was configured to query DC01:

```powershell
Set-DnsClientServerAddress `
    -InterfaceAlias "Ethernet0" `
    -ServerAddresses "192.168.183.10"

ipconfig /flushdns
```

Validation:

```powershell
Get-DnsClientServerAddress `
    -InterfaceAlias "Ethernet0" `
    -AddressFamily IPv4

Test-Connection 192.168.183.10 -Count 2

Resolve-DnsName "northstar.example.com"

Resolve-DnsName `
    -Type SRV `
    "_ldap._tcp.dc._msdcs.northstar.example.com"
```

### Why this is essential

VMware NAT DNS can resolve public Internet names, but it does not host the private Northstar AD records. Domain clients must use AD-aware DNS to locate LDAP, Kerberos, and domain-controller services. A public resolver must not be configured as an alternate client DNS server.

## Step 4 - Join the domain

```powershell
Add-Computer `
    -DomainName "northstar.example.com" `
    -Credential "NORTHSTAR\Administrator" `
    -Restart
```

The credential prompt protected the password from command history.

During the join:

1. CLIENT01 queried DNS for a domain controller.
2. DNS directed it to `DC01.northstar.example.com`.
3. DC01 validated the authorized join credentials.
4. Active Directory created the `CLIENT01` computer object.
5. CLIENT01 and DC01 established a secure channel.
6. CLIENT01 restarted as a domain member.

## Step 5 - Validate domain membership

On CLIENT01:

```powershell
whoami

Get-CimInstance Win32_ComputerSystem |
    Select-Object Name, Domain, PartOfDomain

Test-ComputerSecureChannel
```

Expected results:

```text
Name:          CLIENT01
Domain:        northstar.example.com
PartOfDomain:  True
SecureChannel: True
```

On DC01:

```powershell
Get-ADComputer CLIENT01 |
    Select-Object Name, Enabled, DistinguishedName
```

`Enabled: True` confirms that Active Directory contains an active computer account. The computer can also be viewed in **Active Directory Users and Computers > Computers**.

## Automatic versus prestaged computer accounts

In this lab, the computer account was created automatically during the domain join.

An administrator can instead create the computer object beforehand in Active Directory Users and Computers. This is called **prestaging**. Prestaging reserves and places the AD identity but does not join the actual computer by itself. The client must still complete the join and establish its secure channel.

Prestaging is useful when an organization needs:

- controlled OU placement;
- delegated help-desk joining rights;
- automated deployment;
- standardized naming; or
- Group Policy targeting from the beginning.

## Step 6 - Create and test the first domain user

A domain user was created in Active Directory Users and Computers. Passwords and personal account details are intentionally excluded from this repository.

Optional PowerShell validation on DC01:

```powershell
Get-ADUser -Identity "<username>" -Properties Enabled |
    Select-Object Name, SamAccountName, UserPrincipalName, Enabled, DistinguishedName

Get-ADPrincipalGroupMembership "<username>" |
    Select-Object Name
```

The user successfully signed in to CLIENT01. During that sign-in:

1. CLIENT01 sent the authentication request to DC01.
2. DC01 validated the domain credentials.
3. DC01 supplied the account identity and group memberships.
4. CLIENT01 created a local Windows profile for that domain identity.
5. Windows built an access token for authorization decisions.

The account and password are stored centrally in Active Directory. The user's current desktop and profile files remain on CLIENT01 unless roaming-profile or folder-redirection services are configured later.

Validation from the domain-user session:

```powershell
whoami
```

Expected format:

```text
northstar\<username>
```

## Memory framework - N-D-J-V

Use **N-D-J-V** to reproduce a client join:

1. **Name** - assign the intended workstation name.
2. **DNS** - point the client to AD DNS and resolve the DC locator record.
3. **Join** - authorize membership in the domain.
4. **Verify** - check membership, computer object, secure channel, and user login.

## Technical Competencies Demonstrated

> I prepared a Windows 11 Pro client by assigning a structured computer name and configuring it to use the domain controller's AD-integrated DNS service. I validated the LDAP domain-controller locator record before joining `northstar.example.com`. The join created a computer account and secure channel between CLIENT01 and DC01. I then verified domain membership, confirmed the computer object in Active Directory Users and Computers, created a domain user, and successfully authenticated that user on CLIENT01.

## Sources

- [Microsoft Learn: Add-Computer](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/add-computer)
- [Microsoft Learn: Rename-Computer](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/rename-computer)
- [Microsoft Learn: Test-ComputerSecureChannel](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/test-computersecurechannel)
- [Microsoft Learn: Get-ADComputer](https://learn.microsoft.com/en-us/powershell/module/activedirectory/get-adcomputer)
- [Microsoft Learn: Get-ADUser](https://learn.microsoft.com/en-us/powershell/module/activedirectory/get-aduser)
- [Microsoft Learn: DNS and AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/reviewing-dns-concepts)
- [Microsoft Learn: Active Directory security identifiers](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/understand-security-identifiers)
