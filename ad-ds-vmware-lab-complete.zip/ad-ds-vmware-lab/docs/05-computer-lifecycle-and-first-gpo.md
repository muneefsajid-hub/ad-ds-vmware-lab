# Lab 05 - Computer Lifecycle and First Group Policy

## Status

**Complete**

## Objective

Practise the complete lifecycle of a domain workstation by safely removing CLIENT01 from the domain, observing and deleting the stale Active Directory object, manually prestaging a replacement account in a Workstations OU, rejoining the client, and applying the first user-based Group Policy Object (GPO).

## Learning approach

This lab was intentionally completed through graphical administration tools with minimal command-line use. Each stage followed:

1. Explain the concept.
2. Perform one GUI action.
3. Observe the result.
4. Connect the observation to Active Directory behavior.

## Part 1 - Protect local access

Before removing a domain member, a working local administrator must be confirmed. Otherwise, domain users may become unavailable after the unjoin and the administrator could lose normal access to the workstation.

On CLIENT01, **Computer Management > Local Users and Groups > Users** showed the local `Muneef` account.

![Local accounts on CLIENT01](../assets/screenshots/05-computer-lifecycle-gpo/05-01-local-users.png)

The local **Administrators** group confirmed that `Muneef` had administrative rights.

![Local Administrators membership](../assets/screenshots/05-computer-lifecycle-gpo/05-02-local-administrators.png)

Signing in locally displayed:

```text
Muneef
Local account
```

![Local account confirmation](../assets/screenshots/05-computer-lifecycle-gpo/05-03-local-account-confirmed.png)

### Local versus domain identity

| Identity | Stored by | Works while disconnected from the domain? |
|---|---|---|
| `CLIENT01\Muneef` | CLIENT01 | Yes |
| `NORTHSTAR\<username>` | Active Directory on DC01 | Requires domain connectivity or cached credentials |

The notation `.\Muneef` explicitly asks Windows to use the local CLIENT01 account database.

## Part 2 - Create a recovery checkpoint

CLIENT01 was shut down and the following VMware snapshot was created:

```text
04 - CLIENT01 Domain Joined Baseline
```

The snapshot preserved a working domain-joined client before the removal and prestaging exercise. It is a lab recovery checkpoint, not a substitute for a production backup.

## Part 3 - Verify the operating system and initial membership

Windows Settings provided the authoritative client identification:

```text
Windows 11 Pro
Version 25H2
OS build 26200.8875
```

![Windows 11 and domain baseline](../assets/screenshots/05-computer-lifecycle-gpo/05-04-windows11-domain-baseline.png)

An earlier compatibility-facing PowerShell field displayed `Windows 10 Pro`. The Settings edition, version, and build information confirmed that the guest is Windows 11 Pro. The public documentation was corrected.

Before removal, System Properties showed:

```text
Computer name: CLIENT01
Full computer name: CLIENT01.northstar.example.com
Member of domain: northstar.example.com
```

![CLIENT01 domain membership before removal](../assets/screenshots/05-computer-lifecycle-gpo/05-05-domain-membership-before-removal.png)

## Part 4 - Remove CLIENT01 from the domain

While signed in locally:

1. Opened **Settings > System > About**.
2. Selected **Domain or workgroup**.
3. Opened **Computer Name > Change**.
4. Replaced domain membership with:

```text
WORKGROUP
```

5. Authorized the change with domain administrative credentials.
6. Restarted CLIENT01.
7. Signed in as the local `Muneef` account.

### What changed

- Windows, applications, and local files remained installed.
- The computer name remained `CLIENT01`.
- CLIENT01 became an independent workgroup computer.
- The domain secure channel stopped being active.
- The local account remained usable.
- The Active Directory object remained on DC01 and required inspection.

## Part 5 - Inspect and remove the stale AD object

In **Active Directory Users and Computers > Computers**, the old `CLIENT01` object remained enabled. Its properties still contained:

```text
CLIENT01.northstar.example.com
```

![Stale CLIENT01 computer object](../assets/screenshots/05-computer-lifecycle-gpo/05-06-stale-computer-object.png)

This demonstrated that an enabled AD object does not prove that the physical or virtual computer is currently joined. The stored DNS name had become stale historical information.

After verifying that the VM was safely in `WORKGROUP`, the stale computer object was deleted. Deleting the AD object did not delete the VM, Windows installation, local accounts, or files.

## Part 6 - Create the Workstations OU

A new OU was created:

```text
northstar.example.com
└── Northstar
    ├── Users
    └── Workstations
```

The Workstations OU:

- separates clients from users and servers;
- provides a clear administrative scope;
- supports delegated administration; and
- can receive workstation-targeted GPO links.

The built-in Computers container can store accounts but cannot receive a direct GPO link.

## Part 7 - Manually prestage CLIENT01

Inside `Northstar\Workstations`, **New > Computer** was used to create:

```text
CLIENT01
```

`Domain Admins` retained permission to join the machine. At this stage:

- the AD computer identity existed;
- the real CLIENT01 VM remained in `WORKGROUP`;
- no active secure channel existed; and
- the object became connected only when the real workstation completed the domain join.

Prestaging is similar to preparing a device badge before the device arrives. The badge exists, but the workstation must still authenticate and activate the relationship.

## Part 8 - Verify AD DNS and rejoin

CLIENT01 retained:

| Setting | Value |
|---|---|
| IPv4 assignment | DHCP |
| IPv4 address | `192.168.183.128` |
| Default gateway | `192.168.183.2` |
| DNS server | `192.168.183.10` |

![CLIENT01 DNS before rejoin](../assets/screenshots/05-computer-lifecycle-gpo/05-07-client-dns-before-rejoin.png)

The client must use DC01 at `192.168.183.10` because that DNS server hosts the private AD locator records. VMware DNS or a public resolver may provide Internet name resolution but cannot independently locate Northstar LDAP, Kerberos, and domain-controller services.

CLIENT01 was rejoined through **System Properties > Computer Name > Change**:

```text
Domain: northstar.example.com
```

Domain administrative credentials authorized reuse of the prestaged account. After restart:

- System > About showed `northstar.example.com`;
- the local `Muneef` account still worked;
- CLIENT01 remained inside the Workstations OU; and
- the prestaged object now represented an active domain member.

## Part 9 - Create the first GPO

### Goal

Create a visible and reversible user policy that prevents the test domain user from opening Control Panel and Windows Settings.

### Scope design

```text
Northstar\Users OU
        |
        +-- Northstar - Users - Disable Control Panel
                |
                +-- Test domain user
```

Because the setting is under **User Configuration**, the location of the user object determines scope. CLIENT01 remains in the Workstations OU.

### Create and link

In **Group Policy Management**:

1. Expanded **Forest > Domains > northstar.example.com > Northstar**.
2. Right-clicked the **Users** OU.
3. Selected **Create a GPO in this domain, and Link it here**.
4. Named it:

```text
Northstar - Users - Disable Control Panel
```

Creating and linking are separate concepts:

- The GPO stores settings.
- The link determines where Active Directory evaluates those settings.

### Configure the rule

The GPO was edited at:

```text
User Configuration
└── Policies
    └── Administrative Templates
        └── Control Panel
            └── Prohibit access to Control Panel and PC settings
```

The setting was configured as **Enabled**. This enables the prohibition, so Control Panel and Settings become unavailable to targeted users.

### Force and test policy processing

The target domain user signed in to CLIENT01. To request an immediate policy refresh:

```powershell
gpupdate /force
```

This was the only command introduced in the GPO exercise:

- `gpupdate` asks Windows to refresh Group Policy.
- `/force` reapplies all applicable settings.

Because this is a user setting, signing out and signing back in ensures that the updated user policy is processed.

Expected behavior:

- the target domain user is blocked from Control Panel and Settings;
- the local `Muneef` account remains unaffected; and
- other users outside the linked OU are not targeted by this GPO.

## How Group Policy reaches the client

1. The user signs in to CLIENT01.
2. CLIENT01 locates DC01 through AD DNS.
3. Active Directory evaluates the user’s OU path.
4. CLIENT01 discovers the GPO linked to the Users OU.
5. It reads the policy data from the domain.
6. Windows applies the applicable user setting.

Group Policy is normally pulled and processed by clients during startup, sign-in, and periodic refresh. It is not simply a server pushing arbitrary changes directly into a workstation session.

## Technical Competencies Demonstrated

> I practised the complete workstation account lifecycle. I first verified local administrative access and captured a recovery snapshot. I removed CLIENT01 from the domain, observed that an enabled but stale computer object remained in Active Directory, and deleted it only after confirming the VM was safely in WORKGROUP. I created a Workstations OU, manually prestaged CLIENT01, verified that the client still used AD DNS, and rejoined it to the prestaged identity. I then created and linked a user GPO to the Northstar Users OU, configured a reversible Control Panel restriction, refreshed Group Policy, and tested the result using a domain user.

## Memory frameworks

### Computer lifecycle - L-U-O-P-D-J-V

1. **Local access** - confirm a usable local administrator.
2. **Unjoin** - move the client to a workgroup.
3. **Observe** - inspect the actual machine and AD object separately.
4. **Prestaging location** - create the Workstations OU.
5. **DNS** - verify the client points to AD DNS.
6. **Join** - connect the workstation to the prestaged object.
7. **Validate** - confirm membership and authentication.

### Group Policy - C-L-S-P-T

1. **Create** the GPO.
2. **Link** it to the correct OU.
3. Configure the **Setting**.
4. **Process** the policy on the client.
5. **Test** the intended and unintended identities.

## Sources

- [Microsoft Learn: Join a computer to a domain](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/join-computer-to-domain)
- [Microsoft Learn: Domain join permissions and account reuse](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/active-directory-domain-join-permissions)
- [Microsoft Learn: DNS and AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/reviewing-dns-concepts)
- [Microsoft Learn: OU design concepts](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/reviewing-ou-design-concepts)
- [Microsoft Learn: Group Policy overview](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-overview)
- [Microsoft Learn: gpupdate](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/gpupdate)
- [Microsoft Learn: Windows 11 release information](https://learn.microsoft.com/en-us/windows/release-health/windows11-release-information)
