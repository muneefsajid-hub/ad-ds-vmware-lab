# Lab 07 - SMB File Shares and AGDLP Authorization

## Status

**Complete**

## Objective

Create departmental SMB shares and apply role-based access with the AGDLP framework. Validate both allowed and denied access from CLIENT01.

## AGDLP design

AGDLP means:

```text
Accounts → Global groups → Domain Local groups → Permissions
```

The lab used:

| Department | Accounts become members of | Nested into | Resource permission |
|---|---|---|---|
| IT | `GG_IT_Users` | `DL_IT_Share_Modify` | Modify `\\DC01\IT` |
| HR | `GG_HR_Users` | `DL_HR_Share_Read` | Read `\\DC01\HR` |

Global groups answer **who performs the role**. Domain Local groups answer **who receives access to this domain resource**. NTFS and share permissions are assigned to the Domain Local group.

## IT share

The physical folder and UNC path were:

```text
C:\shares\IT
\\DC01\IT
```

The New Share Wizard configured:

- SMB protocol;
- access-based enumeration enabled;
- offline caching disabled;
- SMB data encryption enabled;
- administrators retained Full Control;
- `DL_IT_Share_Modify` received Change at the share layer; and
- `DL_IT_Share_Modify` received Modify at the NTFS layer.

The effective permission is the most restrictive result of both the share and NTFS permission layers.

### IT validation

An authorized IT user opened `\\DC01\IT`, created a text file, and renamed it. This proved Modify access.

An unauthorized domain user received an access-denied message. This provided negative validation: the share did not merely work; it worked only for the intended role.

## HR practice share

The complete design was repeated independently:

```text
C:\shares\HR
\\DC01\HR
```

`GG_HR_Users` was nested into `DL_HR_Share_Read`. The Domain Local group received Read and Execute on the folder. Testing confirmed that an authorized HR user could open and read the share without receiving modify rights.

## Why permissions were not assigned directly to users

Direct user permissions become difficult to audit and maintain. AGDLP separates four decisions:

1. The account represents a person or service.
2. The Global group represents a business role.
3. The Domain Local group represents access to a resource.
4. The resource ACL stores the actual permission.

When an employee changes departments, administrators change Global-group membership instead of editing every resource ACL.

## Technical Competencies Demonstrated

> I implemented two departmental SMB shares on Windows Server using AGDLP. User accounts were assigned to role-based Global groups, those Global groups were nested in resource-specific Domain Local groups, and only the Domain Local groups were placed on the share and NTFS ACLs. I validated IT Modify access, HR Read access, and access denial for an unauthorized user. I also enabled access-based enumeration and SMB encryption and disabled offline caching.

## Validation checklist

- [x] IT Global group contains the intended role members.
- [x] IT Global group is nested in the IT Domain Local permission group.
- [x] Authorized IT user can create and rename a file.
- [x] Unauthorized user is denied access.
- [x] HR Global group is nested in the HR Domain Local permission group.
- [x] Authorized HR user has read-only access.
- [x] Administrators and SYSTEM retain Full Control.

## Sources

- [Microsoft Learn: Active Directory security groups](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/understand-security-groups)
- [Microsoft Learn: SMB file shares](https://learn.microsoft.com/en-us/windows-server/storage/file-server/file-server-smb-overview)
- [Microsoft Learn: Share and NTFS permissions](https://learn.microsoft.com/en-us/windows-server/storage/file-server/configure-share-permissions)
- [Microsoft Learn: Access-based enumeration](https://learn.microsoft.com/en-us/windows-server/storage/dfs-namespaces/enable-access-based-enumeration-on-a-namespace)
- [Microsoft Learn: SMB security enhancements](https://learn.microsoft.com/en-us/windows-server/storage/file-server/smb-security)
