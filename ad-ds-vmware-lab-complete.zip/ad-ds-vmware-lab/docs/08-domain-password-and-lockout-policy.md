# Lab 08 - Domain Password and Account-Lockout Policy

## Status

**Complete - domain baseline configured and protected by a GPO backup**

## Objective

Back up the existing Default Domain Policy, review the inherited domain security baseline, strengthen the minimum password length, and configure an account-lockout baseline.

## Why this policy is domain-wide

The password and lockout rules protect domain accounts, not only one workstation or department. They are therefore configured in a GPO linked at the domain level. In this single-domain lab, the existing **Default Domain Policy** supplies that account-policy baseline.

## Change-control checkpoint

Before editing the policy:

1. Created `C:\GPO-Backups` on DC01.
2. Opened Group Policy Management.
3. Expanded `northstar.example.com > Group Policy Objects`.
4. Right-clicked **Default Domain Policy** and selected **Back Up**.
5. Added the description:

```text
Baseline before password and account lockout policy lab
```

6. Confirmed that the backup completed successfully.

![Default Domain Policy backup succeeded](../assets/screenshots/08-domain-security-policy/08-01-default-domain-policy-backup.png)

The backup provides a controlled rollback point for the GPO. It is not a complete Active Directory or server backup.

## Password-policy review

The existing baseline was:

| Setting | Observed value |
|---|---:|
| Enforce password history | 24 remembered passwords |
| Maximum password age | 42 days |
| Minimum password age | 1 day |
| Minimum password length | 7 characters |
| Complexity requirements | Enabled |
| Reversible encryption | Disabled |

![Password-policy baseline](../assets/screenshots/08-domain-security-policy/08-02-password-policy-baseline.png)

Only the minimum password length was changed:

```text
7 characters → 8 characters
```

The other existing settings were retained to avoid weakening the baseline. Existing passwords are not automatically rewritten; the new minimum is evaluated when a domain password is created or changed.

## Account-lockout configuration

The following domain settings were configured:

| Setting | Lab value |
|---|---:|
| Account lockout threshold | 5 invalid attempts |
| Account lockout duration | 10 minutes |
| Reset account lockout counter after | 10 minutes |
| Allow Administrator account lockout | Enabled |

![Suggested lockout values after defining a five-attempt threshold](../assets/screenshots/08-domain-security-policy/08-03-lockout-suggested-values.png)

### How the counter behaves

- Attempts one through four fail without immediately locking the user.
- The fifth invalid attempt locks the account.
- The account remains locked for 10 minutes unless an administrator unlocks it sooner.
- If the threshold is not reached, 10 minutes without another failure resets the failure counter.

The validation must use a standard test user, never the administrative account.

## Optional follow-up enforcement test

1. Close the Group Policy editor.
2. Run `gpupdate /force` on DC01 to request immediate policy processing.
3. On CLIENT01, deliberately enter the wrong password five times for a standard test user.
4. Attempt the correct password and confirm that sign-in is denied because the account is locked.
5. In Active Directory Users and Computers, inspect the user's **Account** properties.
6. Unlock the account and confirm that the correct password works.
7. Test the eight-character minimum during a controlled password change.

This controlled enforcement exercise was not required for the completed configuration scope. It is retained as an optional future practice task and must use a standard test account rather than an administrative account.

## Technical Competencies Demonstrated

> Before changing a domain-wide security policy, I backed up the Default Domain Policy to create a rollback point. I reviewed the existing password baseline, increased the minimum password length from seven to eight characters, and configured a five-attempt account-lockout threshold with a ten-minute duration and reset window. I retained the stronger existing history, age, complexity, and reversible-encryption settings instead of replacing them with weaker values. The policy configuration completed the defined scope; a controlled enforcement exercise remains available as optional practice using a standard account.

## Memory framework - B-R-C-T-R

1. **Back up** the current GPO.
2. **Review** the existing baseline.
3. **Configure** the smallest intended change.
4. **Test** with a nonadministrative account.
5. **Recover** by unlocking or restoring when necessary.

## Sources

- [Microsoft Learn: Back up and restore Group Policy](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-backup-restore)
- [Microsoft Learn: Password policy](https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/password-policy)
- [Microsoft Learn: Minimum password length](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/security-policy-settings/minimum-password-length)
- [Microsoft Learn: Account lockout policy](https://learn.microsoft.com/en-us/windows/security/threat-protection/security-policy-settings/account-lockout-policy)
- [Microsoft Learn: gpupdate](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/gpupdate)
