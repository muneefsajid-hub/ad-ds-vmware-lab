# Architecture and Design Decisions

## Business scenario

Northstar Technologies is a fictional organization requiring centralized identity, device administration, department-based access, consistent workstation configuration, and recoverable directory services.

## Final logical design

| Component | Proposed value | Decision status |
|---|---|---|
| Forest | `northstar.example.com` | Implemented |
| Root domain | `northstar.example.com` | Implemented |
| NetBIOS name | `NORTHSTAR` | Implemented |
| First domain controller | `DC01` | Approved |
| First client | `CLIENT01` | Approved |
| DNS | AD-integrated DNS on `DC01` | Implemented |
| Virtual network | VMware NAT, `192.168.183.0/24` | Implemented |
| Domain-controller count | One | Final scope |

## Virtual-machine resource plan

| System | vCPU | Memory | Storage |
|---|---:|---:|---:|
| `DC01` | 2 | 4 GB | 60 GB dynamically expanding |
| `CLIENT01` | 2 | 4 GB | Existing virtual disk |

The physical host provides 4 CPU cores, 8 logical processors, approximately 16 GB of memory, and 136.36 GB of available storage. After closing the Windows 11 VM and unnecessary browser tabs, available memory increased from 2.13 GB to 7.02 GB. The resource plan therefore depends on closing unrelated workloads while both lab systems are active.

## Design principles

1. **Use fictional data.** No real organization, employee, or customer information will enter the lab.
2. **Prefer the simplest workable design.** One forest and one domain are sufficient for the initial learning environment.
3. **Separate roles clearly.** `DC01` provides directory and DNS services; `CLIENT01` represents an end-user workstation.
4. **Make changes recoverable.** Snapshots will be created at defined milestones.
5. **Validate every phase.** A configuration is not considered complete until its expected behavior is tested.
6. **Document decisions, not only clicks.** Each setting will include a short technical rationale.

## Implemented OU model

The completed lab uses the following simplified structure:

```text
NorthStar
├── Users
├── Workstations
└── Groups
```

Departmental access is represented through role-based security groups, while GPO links and computer placement use the appropriate OUs. This educational design is intentionally smaller than a production directory.

## Change record

| Date | Decision | Reason |
|---|---|---|
| 2026-07-23 | Use a dedicated server VM and existing Windows 11 client VM | Separates server and client responsibilities |
| 2026-07-23 | Document the project as a GitHub portfolio repository | Demonstrates technical work and communication skills |
| 2026-07-23 | Allocate 2 vCPUs and 4 GB memory to each lab VM | Fits the verified 4-core, 16 GB host without allocating all host resources |
| 2026-07-23 | Retain 4 GB as the initial `DC01` allocation | A clean host baseline provides 7.02 GB available memory; allocation can be reduced to 3 GB if measured performance requires it |
| 2026-07-23 | Use Windows Server 2022 for `DC01` | Existing installation media is available and Windows Server 2022 supports the required AD DS lab features |
| 2026-08-08 | Close the lab as a single-domain-controller portfolio project | The defined learning objectives for deployment, identity, Group Policy, AGDLP, file access, security policy, recovery, and troubleshooting were completed; replication is outside the current scope |
