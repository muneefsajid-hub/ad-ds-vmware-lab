# Screenshot Standards

## Naming convention

Use:

```text
phase-evidence-number-short-description.png
```

Examples:

```text
00-01-windows-edition.png
01-02-server-vm-hardware.png
03-04-ad-ds-role-installed.png
04-03-client-domain-join.png
```

## Capture requirements

- Capture only the application area needed to prove the result.
- Keep text readable at normal GitHub width.
- Use one image for one clear point.
- Write a short caption explaining what the image proves.
- Prefer screenshots taken after validation, not during an unfinished dialog.

## Information to remove

Before committing an image, check for:

- passwords or password hints;
- product keys and recovery keys;
- personal email addresses;
- public IP addresses;
- physical hostnames or usernames;
- browser bookmarks and unrelated tabs;
- notifications containing personal information;
- file paths containing personal names;
- Wi-Fi names or nearby network details;
- private organization or customer information.

## Suggested folders

```text
assets/screenshots/
├── 00-planning/
├── 01-server-deployment/
├── 02-networking/
├── 03-domain-deployment/
├── 04-domain-join/
├── 05-directory-administration/
├── 06-group-policy/
├── 07-access-control/
├── 08-replication/
└── 09-troubleshooting/
```

