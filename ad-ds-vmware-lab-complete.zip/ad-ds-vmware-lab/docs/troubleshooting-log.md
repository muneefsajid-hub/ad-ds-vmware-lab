# Troubleshooting Log

Record problems as evidence of diagnostic reasoning. Do not hide unsuccessful attempts; describe them professionally and show how the cause was isolated.

## INC-001 - AD-integrated DNS zones missing after first promotion

**Date:** 2026-07-23  
**Affected system:** `DC01`  
**Symptoms:** The first `northstar.example` forest promotion completed, but the domain and `_msdcs` forward zones were absent. AD DNS queries failed, DNS event 4013 appeared, and normal zone-creation commands returned `ERROR_INVALID_NAME 123`.

**Expected behavior:** Promotion of the first domain controller should create AD-integrated domain and forest DNS zones and register DC locator records.

**Diagnostics performed:**

| Step | Test | Observation |
|---:|---|---|
| 1 | Checked DNS, Netlogon, KDC, and NTDS services | Services were running |
| 2 | Queried DNS zones | Only default reverse zones existed |
| 3 | Queried the domain and LDAP SRV record | Both returned name-not-found errors |
| 4 | Tested local LDAP TCP 389 and RPC TCP 135 | Both listeners responded |
| 5 | Inspected AD naming contexts and replication | DNS application partitions existed; no partner errors on the single DC |
| 6 | Retried DNS registration and restart | Required zones remained absent |
| 7 | Attempted normal PowerShell and `dnscmd` zone creation | Windows returned `ERROR_INVALID_NAME 123` |

**Root cause:** The exact Windows-internal cause was not conclusively established. The confirmed fault was an unusable AD DNS namespace after promotion. The original server state was not accepted as healthy.

**Resolution:** Restored `02 - DC01 Pre-AD DS Configuration`, verified the restored baseline, reinstalled AD DS, and created the corrected `northstar.example.com` forest.

**Validation:** The rebuilt forest contained `northstar.example.com` and `_msdcs.northstar.example.com` as AD-integrated zones. The DC host and LDAP SRV records resolved, and `nltest` located `DC01`.

**Lesson learned:** Use a pre-promotion snapshot, validate DNS immediately after promotion, and rebuild from a known-good state when foundational directory data is incomplete rather than hiding the failure with manual records.

## INC-002 - Domain controller network profile remained Public

**Date:** 2026-07-23  
**Affected system:** `DC01`  
**Symptoms:** DNS and DC discovery worked, but `Get-NetConnectionProfile` reported `Public`. Restarting the Network Location Awareness service timed out.

**Expected behavior:** A domain controller with working DNS and domain discovery should automatically use the `DomainAuthenticated` profile.

**Diagnostics performed:**

| Step | Test | Observation |
|---:|---|---|
| 1 | Verified AD-integrated DNS zones | Domain and `_msdcs` zones existed |
| 2 | Resolved LDAP SRV and DC host records | Both succeeded |
| 3 | Pointed `Ethernet0` DNS to `192.168.183.10` | DC began querying its own AD DNS service |
| 4 | Ran `nltest /dsgetdc:northstar.example.com` | DC Locator succeeded with required flags |
| 5 | Restarted NLA service | Operation timed out and profile remained Public |
| 6 | Disabled and re-enabled `Ethernet0` from the local VMware console | Windows reevaluated the network |

**Root cause:** Network Location Awareness retained a stale classification created before AD DNS and domain discovery were healthy.

**Resolution:** Reset the virtual adapter after confirming correct DNS and successful domain-controller discovery.

**Validation:** `Get-NetConnectionProfile` returned `northstar.example.com` and `DomainAuthenticated`.

**Lesson learned:** Do not force a domain network to Private or disable the firewall. Correct DNS and DC discovery first, then trigger network reevaluation.

## Incident template

### INC-000 - Short problem title

**Date:** YYYY-MM-DD  
**Affected systems:** `HOSTNAME`  
**Symptoms:**  
Describe the observed behavior and exact error message.

**Expected behavior:**  
Describe what should have happened.

**Initial hypotheses:**

1. First likely cause.
2. Second likely cause.
3. Third likely cause.

**Diagnostics performed:**

| Step | Test or command | Observation |
|---:|---|---|
| 1 | Diagnostic action | Result |

**Root cause:**  
State the confirmed cause. Do not label a guess as the root cause.

**Resolution:**  
Describe the change that corrected the problem.

**Validation:**  
State how normal operation was confirmed.

**Lesson learned:**  
Explain how the incident improved future troubleshooting.
