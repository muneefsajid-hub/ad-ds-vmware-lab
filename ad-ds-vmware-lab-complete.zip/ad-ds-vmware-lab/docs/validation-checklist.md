# Validation Checklist

This file records the tests used to prove that each lab phase works as intended.

| Test ID | Phase | Test | Expected result | Status |
|---|---:|---|---|---|
| VAL-001 | 0 | Verify Windows 11 edition | Windows 11 Pro supports domain joining | Passed |
| VAL-002 | 0 | Inspect server recovery snapshot | `01 - Windows Server 2022 Clean Install` is available | Passed |
| VAL-002A | 0 | Verify host capacity | 4 cores, 8 logical processors, 15.73 GB RAM, and 128.9 GB free storage recorded | Passed |
| VAL-003 | 1 | Start `DC01` | Server reaches the Windows desktop successfully | Passed |
| VAL-003A | 1 | Verify server resources | 2 logical processors, 4 GB RAM, and approximately 60 GB system disk are reported | Passed |
| VAL-003B | 1 | Verify VMware Tools | `VMTools` service reports `Running` | Passed |
| VAL-003C | 1 | Verify Secure Boot | `Confirm-SecureBootUEFI` returns `True` | Passed |
| VAL-003D | 2 | Verify Windows computer name | `hostname` returns `DC01` | Passed |
| VAL-003E | 2 | Verify static addressing | `DC01` uses `192.168.183.10/24` with gateway `192.168.183.2` | Passed |
| VAL-003F | 2 | Verify DNS and HTTPS connectivity | Name resolution succeeds and TCP 443 test returns `True` | Passed |
| VAL-003G | 2 | Verify time configuration | Eastern time zone and Windows Time synchronization are confirmed | Passed |
| VAL-003H | 2 | Verify operating-system updates | Required Windows updates are installed and configuration persists after restart | Passed |
| VAL-004 | 2 | Test server gateway and Internet reachability | Gateway responds and HTTPS connection succeeds | Passed |
| VAL-005 | 3 | Query AD DS DNS records | `DC01` host record and `_ldap._tcp.dc._msdcs` SRV record resolve | Passed |
| VAL-005A | 3 | Verify AD-integrated zones | `northstar.example.com` and `_msdcs.northstar.example.com` exist and are AD-integrated | Passed |
| VAL-005B | 3 | Verify domain identity | DNS root, NetBIOS name, functional level, and PDC emulator match the design | Passed |
| VAL-005C | 3 | Verify DC discovery | `nltest /dsgetdc:northstar.example.com` locates `DC01` with required service flags | Passed |
| VAL-005D | 3 | Verify network profile | `Get-NetConnectionProfile` reports `DomainAuthenticated` | Passed |
| VAL-005E | 3 | Create healthy-forest recovery checkpoint | Snapshot `03 - AD DS Forest Healthy` exists before the client domain join | Passed |
| VAL-006 | 3 | Run domain-controller service and DNS checks | AD DS, DNS, Kerberos, Netlogon, NTDS, locator records, and AD-integrated zones report expected results | Passed |
| VAL-007 | 4 | Join `CLIENT01` to the domain | Domain join succeeds and restart completes | Passed |
| VAL-007A | 4 | Verify client secure channel | `Test-ComputerSecureChannel` returns `True` on CLIENT01 | Passed |
| VAL-007B | 4 | Verify computer account | `CLIENT01` appears enabled in Active Directory Users and Computers | Passed |
| VAL-008 | 4 | Sign in as a domain user | Domain authentication succeeds and `whoami` identifies `NORTHSTAR` | Passed |
| VAL-008A | 5 | Verify local recovery account | Local `Muneef` account is enabled and belongs to local Administrators | Passed |
| VAL-008B | 5 | Remove CLIENT01 from domain | CLIENT01 restarts in `WORKGROUP` and local login succeeds | Passed |
| VAL-008C | 5 | Inspect and remove stale computer object | Old enabled `CLIENT01` object is observed and intentionally deleted | Passed |
| VAL-008D | 5 | Prestage CLIENT01 | New computer object appears in `Northstar\Workstations` | Passed |
| VAL-008E | 5 | Rejoin prestaged computer | System > About reports `northstar.example.com` | Passed |
| VAL-008F | 6 | Reset a domain-user password | User signs in with the replacement password | Passed |
| VAL-008G | 6 | Disable a domain user | CLIENT01 rejects a new sign-in and reports that the account is disabled | Passed |
| VAL-008H | 6 | Re-enable a domain user | Correct credentials authenticate successfully again | Passed |
| VAL-010A | 6 | Create and link first user GPO | Control Panel restriction GPO is linked to `Northstar\Users` | Passed |
| VAL-010B | 6 | Force Group Policy refresh | `gpupdate /force` completes for the target domain user | Passed |
| VAL-010C | 6 | Roll back the Control Panel restriction | Removing the link and refreshing policy restores access | Passed |
| VAL-009 | 7 | Test IT group-based Modify access | Authorized IT role can create and rename a file | Passed |
| VAL-009A | 7 | Test unauthorized IT-share access | User outside the authorized group is denied | Passed |
| VAL-009B | 7 | Test HR group-based Read access | Authorized HR role can open and read the share | Passed |
| VAL-010 | 6 | Apply a test GPO | Target client receives intended policy | Passed |
| VAL-010D | 8 | Back up Default Domain Policy | GPMC reports that the backup succeeded | Passed |
| VAL-010E | 8 | Configure domain password baseline | Minimum length reports 8 characters and existing stronger settings remain | Passed |
| VAL-010F | 8 | Configure account lockout | Threshold 5, duration 10 minutes, and reset window 10 minutes are defined | Passed |
| VAL-010G | 8 | Optional account-lockout enforcement exercise | Fifth invalid sign-in locks a standard test user | Optional follow-up |
| VAL-010H | 8 | Optional password-minimum enforcement exercise | Password shorter than 8 characters is rejected during a controlled change | Optional follow-up |

The portfolio lab is complete within its defined single-domain-controller scope. Multi-domain-controller replication is not part of the current design.
