# Lab 06 - Identity, Groups, and Group Policy Validation

## Status

**Complete**

## Objective

Practise everyday Active Directory administration through the graphical tools: organize objects with OUs, provision users, assign access through security groups, validate a user-targeted Group Policy Object, and safely remove that policy after testing.

## Directory structure

The Northstar OU structure was expanded to separate identities by purpose:

```text
northstar.example.com
└── NorthStar
    ├── Users
    │   ├── HR_Users
    │   └── IT_Users
    ├── Groups
    └── Workstations
```

OUs provide administrative and Group Policy scope. Security groups provide authorization. An OU is not a substitute for a permission group.

## User provisioning

A test domain user was created through **Active Directory Users and Computers** and placed in the appropriate departmental OU. The user successfully authenticated on `CLIENT01`, proving that:

- the account existed and was enabled;
- CLIENT01 could locate DC01 through AD DNS;
- the workstation trusted the Northstar domain; and
- DC01 accepted the supplied domain credentials.

Passwords and personally identifying account details are intentionally excluded.

## Security-group design

Role-based global groups were created:

```text
GG_IT_Users
GG_HR_Users
```

The prefix identifies both scope and purpose:

- `GG` means global group;
- `IT` or `HR` identifies the business role; and
- `Users` describes the membership population.

Users were placed into the appropriate global group instead of being granted permissions directly. This separates identity management from resource permissions.

## User Group Policy test

The reversible GPO `Northstar - Users - Disable Control Panel` was linked to the Northstar Users OU. Its user-side policy prohibited access to Control Panel and Windows Settings.

The test followed:

1. Create the GPO.
2. Link it to the intended OU.
3. Configure the user setting.
4. Refresh policy on CLIENT01.
5. Sign in as the targeted domain user.
6. Confirm that Control Panel was blocked.
7. Remove the GPO link.
8. Refresh policy and confirm that Control Panel worked again.

Removing the link changed scope without deleting the GPO itself. This demonstrated a controlled rollback and proved that the earlier restriction was caused by Group Policy rather than a local Windows problem.

## Account administration exercise

The same domain account was used to practise:

- administrative password reset;
- successful sign-in with the replacement password;
- disabling the account;
- confirming that Windows rejected a new sign-in;
- re-enabling the account; and
- restoring successful authentication.

When disabled, the account and its group memberships remained in Active Directory, but new authentication was blocked. This is useful for temporary suspension, suspected compromise, or the first stage of an offboarding workflow. Disabling is normally safer than immediately deleting an account because access can be restored without creating a new security principal.

## Interview-ready explanation

> I used Active Directory Users and Computers to provision and organize users, computers, and role-based security groups. I validated authentication from a domain-joined Windows 11 client, reset a user password, disabled the account to revoke new sign-ins, and re-enabled it to restore access. I also created and linked a reversible user GPO, validated its effect on the intended user, removed the link, and confirmed the restriction was rolled back.

## Memory framework - P-A-V-R

1. **Provision** the identity.
2. **Authorize** through groups.
3. **Validate** authentication and policy.
4. **Revoke or restore** access as required.

## Sources

- [Microsoft Learn: Manage user accounts in Active Directory](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage-user-accounts-in-windows-server)
- [Microsoft Learn: Active Directory security groups](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/understand-security-groups)
- [Microsoft Learn: Group Policy overview](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-overview)
- [Microsoft Learn: Group Policy Management Console](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-management-console)

