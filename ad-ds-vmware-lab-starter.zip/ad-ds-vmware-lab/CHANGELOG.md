# Changelog

All significant project updates will be recorded here.

## [Unreleased]

### Added

- Initial portfolio README.
- Lab 00 planning and prerequisite documentation.
- Preliminary architecture and design principles.
- Validation checklist.
- Troubleshooting incident template.
- Screenshot privacy and naming standards.
- Lab 01 Windows Server 2022 VM deployment guide with interview revision questions.
- Sanitized PowerShell validation evidence for the completed Windows Server deployment.
- Lab 03 guide covering AD DS role installation, forest promotion, AD-integrated DNS, validation, recovery, and interview preparation.
- Troubleshooting records for missing DNS zones and a stale Public network profile.
- Sanitized evidence showing the corrected domain, DNS zones, locator records, DC discovery, and DomainAuthenticated profile.

### Verified

- Confirmed that the existing client virtual machine runs Windows 11 Pro and supports an AD DS domain join.
- Recorded the physical host's CPU, memory, and available-storage capacity.
- Recorded a clean host baseline of 7.02 GB available memory and 136.36 GB free storage after workload cleanup.
- Installed Windows Server 2022 Standard Evaluation with Desktop Experience.
- Verified 4 GB RAM, 2 logical processors, a 59.37 GB system disk, running VMware Tools, and UEFI Secure Boot.
- Created the powered-off baseline snapshot `01 - Windows Server 2022 Clean Install`.
- Created and used `02 - DC01 Pre-AD DS Configuration` as a recovery checkpoint.
- Installed AD DS and created the `northstar.example.com` forest with NetBIOS name `NORTHSTAR`.
- Verified the domain and `_msdcs` zones as AD-integrated.
- Verified the LDAP SRV record, `DC01` host record, and DC Locator response.
- Corrected the stale Public profile and verified `DomainAuthenticated`.
- Created snapshot `03 - AD DS Forest Healthy` before beginning the client domain-join phase.

### Changed

- Added a resource plan of 2 vCPUs and 4 GB RAM for each lab VM.
- Added an operational note to close unnecessary applications when both VMs are running.
- Retained 4 GB as the initial `DC01` memory allocation with a documented 3 GB fallback if host performance becomes unacceptable.
- Changed the planned `DC01` operating system from Windows Server 2025 to Windows Server 2022 to use the installation media already available.
- Marked Lab 01 complete and documented the full VM creation, operating-system installation, troubleshooting, and validation procedure.
- Added the IACP interview-memory framework, networking design, static-IP configuration, time validation, update procedure, and command-learning strategy to Lab 02.
- Marked planning, networking, server preparation, and forest deployment complete.
- Corrected the lab forest design from the unsuccessful `northstar.example` deployment to `northstar.example.com`.
