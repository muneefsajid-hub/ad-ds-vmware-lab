# Active Directory Domain Services Home Lab

![Status](https://img.shields.io/badge/status-in%20progress-2563eb)
![Platform](https://img.shields.io/badge/platform-VMware%20Workstation%20Pro-607078)
![Server](https://img.shields.io/badge/server-Windows%20Server%202022-0078d4)
![Client](https://img.shields.io/badge/client-Windows%2011-0078d4)

## Project overview

This project documents the design and implementation of a virtualized Microsoft Active Directory Domain Services (AD DS) environment. The lab is being built in VMware Workstation Pro to demonstrate practical skills in Windows Server administration, identity management, DNS, Group Policy, access control, troubleshooting, and technical documentation.

The environment represents a fictional company named **Northstar Technologies**. All names, addresses, users, and credentials used in the project are fictional.

> **Current status:** `DC01` is a healthy domain controller for `northstar.example.com`. AD-integrated DNS and the DomainAuthenticated network profile have been validated. The next phase is joining `CLIENT01`.

## Project objectives

- Deploy Windows Server 2022 as a virtual machine.
- Configure a safe, isolated VMware lab network.
- Install AD DS and create a new forest.
- Configure integrated DNS services.
- Join a Windows 11 client to the domain.
- Design organizational units for users, groups, computers, and administrators.
- Create role-based security groups.
- Implement account provisioning and deprovisioning workflows.
- Apply and troubleshoot Group Policy Objects.
- Configure file-sharing and NTFS permissions.
- Add a second domain controller and validate replication.
- Document testing, failures, resolutions, and lessons learned.

## Planned environment

| System | Hostname | Role | Operating system |
|---|---|---|---|
| Domain controller | `DC01` | AD DS, DNS | Windows Server 2022 with Desktop Experience |
| Client workstation | `CLIENT01` | Domain-joined endpoint | Windows 11 Pro |
| VMware host | Not documented publicly | Hypervisor host | Windows |

The lab uses the `northstar.example.com` forest on VMware NAT network `192.168.183.0/24`. `DC01` has static address `192.168.183.10`.

## Architecture

```mermaid
flowchart LR
    Host["Windows host<br/>VMware Workstation Pro"]
    Net["Private VMware lab network"]
    DC["DC01<br/>AD DS + DNS"]
    Client["CLIENT01<br/>Windows 11"]

    Host --> Net
    DC <--> Net
    Client <--> Net
```

## Implementation roadmap

| Phase | Deliverable | Status |
|---:|---|---|
| 0 | Prerequisite assessment and recovery snapshot | Complete |
| 1 | Windows Server VM deployment | Complete |
| 2 | VMware networking and static addressing | Complete |
| 3 | AD DS installation and forest creation | Complete |
| 4 | Windows 11 domain join | Not started |
| 5 | OU, user, and group administration | Not started |
| 6 | Group Policy configuration | Not started |
| 7 | File shares and access control | Not started |
| 8 | Second domain controller and replication | Not started |
| 9 | Troubleshooting scenarios and final validation | Not started |

## Skills demonstrated

- VMware virtual-machine administration
- Windows Server deployment
- Active Directory Domain Services
- DNS and service discovery
- User and computer account management
- Security-group design
- Organizational-unit design and delegation
- Group Policy administration
- NTFS and share permissions
- PowerShell fundamentals
- Testing and technical troubleshooting
- Change documentation

## Documentation

- [Lab 00 - Planning and prerequisites](docs/00-planning-and-prerequisites.md)
- [Lab 01 - Deploying the Windows Server 2022 VM](docs/01-windows-server-vm-deployment.md)
- [Lab 02 - Preparing DC01](docs/02-domain-controller-preparation.md)
- [Lab 03 - Installing AD DS and creating the forest](docs/03-ad-ds-forest-deployment.md)
- [Architecture and design decisions](docs/architecture.md)
- [Validation checklist](docs/validation-checklist.md)
- [Troubleshooting log](docs/troubleshooting-log.md)
- [Screenshot standards](docs/screenshot-standards.md)
- [Project changelog](CHANGELOG.md)

Additional implementation guides will be added after each completed lab phase.

## Security and privacy

- This is an isolated educational environment, not a production deployment.
- Lab passwords and recovery secrets are never committed.
- Screenshots are reviewed and sanitized before publication.
- Personal hostnames, email addresses, IP addresses, license keys, and unrelated applications are excluded.
- Placeholder accounts and fictional employee information are used throughout the project.

## References

- [Microsoft Learn: Active Directory Domain Services overview](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/virtual-dc/active-directory-domain-services-overview)
- [Microsoft Learn: Install Active Directory Domain Services](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/install-active-directory-domain-services--level-100-)
- [Microsoft Evaluation Center: Windows Server 2022](https://www.microsoft.com/en-us/evalcenter/evaluate-windows-server-2022)
- [Broadcom: Configuring host-only networking in VMware Workstation Pro](https://techdocs.broadcom.com/us/en/vmware-cis/desktop-hypervisors/workstation-pro/17-0/using-vmware-workstation-pro/configuring-network-connections/configuring-host-only-networking.html)

## Author

**Muhammad Muneef Sajid**  
Information Technology Graduate
