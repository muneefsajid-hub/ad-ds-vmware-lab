# Lab 03 - Installing AD DS and Creating the Northstar Forest

## Status

**Complete**

## Objective

Install Active Directory Domain Services (AD DS), promote `DC01` as the first domain controller in a new forest, validate AD-integrated DNS, and correct the Windows network profile.

## Final configuration

| Setting | Value |
|---|---|
| Server | `DC01` |
| Forest and DNS domain | `northstar.example.com` |
| NetBIOS domain | `NORTHSTAR` |
| Domain-controller FQDN | `DC01.northstar.example.com` |
| Static IPv4 address | `192.168.183.10/24` |
| Default gateway | `192.168.183.2` |
| Preferred DNS server | `192.168.183.10` |
| Forest functional level | Windows Server 2016 |
| Domain functional level | Windows Server 2016 |
| Domain-controller capabilities | DNS server and Global Catalog |
| Network profile | `DomainAuthenticated` |

## Concept: installing a role versus promoting a server

Installing the **AD DS role** adds the binaries and management tools. It does not create a domain or turn the server into a domain controller.

**Promotion** creates or joins the Active Directory structure, configures the directory database and SYSVOL, registers domain-controller DNS records, and restarts the server as a domain controller.

## Step 1 - Install the AD DS role

In Server Manager:

1. Select **Manage > Add Roles and Features**.
2. Choose **Role-based or feature-based installation**.
3. Select `DC01` from the server pool.
4. Select **Active Directory Domain Services**.
5. Select **Add Features** when the required management tools appear.
6. Leave the already-installed **File and Storage Services** role unchanged.
7. Continue through **Features** without adding unrelated features.
8. Review the confirmation screen and select **Install**.

The automatic-restart option was left unchecked because installing the role did not require a restart. Promotion later performs a planned restart.

![AD DS role installation confirmation](../assets/screenshots/03-ad-ds-forest-deployment/03-01-role-installation-confirmation.png)

### PowerShell equivalent

```powershell
Install-WindowsFeature `
    -Name AD-Domain-Services `
    -IncludeManagementTools
```

Validation:

```powershell
Get-WindowsFeature AD-Domain-Services, DNS |
    Select-Object Name, InstallState
```

## Step 2 - Promote DC01

After role installation, Server Manager displayed a notification flag. Selecting **Promote this server to a domain controller** opened the AD DS Configuration Wizard.

The deployment choices were:

- **Add a new forest**
- Root domain: `northstar.example.com`
- Forest functional level: **Windows Server 2016**
- Domain functional level: **Windows Server 2016**
- **DNS server:** selected
- **Global Catalog:** selected
- **Read-only domain controller:** not selected
- NetBIOS domain: `NORTHSTAR`
- Database path: `C:\Windows\NTDS`
- Log path: `C:\Windows\NTDS`
- SYSVOL path: `C:\Windows\SYSVOL`
- A private Directory Services Restore Mode password

The DNS-delegation checkbox was not selected. This lab creates the first DNS namespace for a new forest, so no authoritative parent Windows DNS zone exists in which to create a delegation. The resulting warning was expected.

The prerequisite check passed before installation.

![Promotion prerequisite check](../assets/screenshots/03-ad-ds-forest-deployment/03-02-promotion-prerequisites.png)

### Why the functional level says Windows Server 2016

Windows Server 2022 does not introduce a newer AD DS functional level. A Windows Server 2016 functional level is therefore normal for this Windows Server 2022 forest.

### Why the NetBIOS name is uppercase

`NORTHSTAR` is the short, legacy-compatible domain name. Its uppercase display is conventional and does not change the DNS domain `northstar.example.com`.

### Why the default paths were retained

The default NTDS and SYSVOL paths are appropriate for a single-disk educational lab. Production deployments may place the database and logs on separate storage according to performance, recovery, and organizational requirements.

## Step 3 - Validate the forest and DNS

After promotion and restart, the Administrator account became the domain account:

```text
NORTHSTAR\Administrator
```

### Validate the domain

```powershell
Get-ADDomain |
    Select-Object DNSRoot, NetBIOSName, DomainMode, PDCEmulator
```

Expected values include:

```text
DNSRoot      northstar.example.com
NetBIOSName  NORTHSTAR
DomainMode   Windows2016Domain
PDCEmulator  DC01.northstar.example.com
```

### Validate AD-integrated DNS zones

```powershell
Get-DnsServerZone |
    Select-Object ZoneName, ZoneType, IsDsIntegrated
```

The important zones are:

- `northstar.example.com`
- `_msdcs.northstar.example.com`

Both are primary, AD-integrated zones.

![Corrected domain and AD-integrated zones](../assets/screenshots/03-ad-ds-forest-deployment/03-05-corrected-domain-and-zones.png)

### Validate domain-controller locator records

```powershell
Resolve-DnsName `
    -Type SRV `
    "_ldap._tcp.dc._msdcs.northstar.example.com"

Resolve-DnsName "DC01.northstar.example.com"
```

The SRV record pointed to `DC01.northstar.example.com`, and the host record resolved to `192.168.183.10`.

![SRV and host-record validation](../assets/screenshots/03-ad-ds-forest-deployment/03-06-srv-and-host-records.png)

### Configure the domain controller to use AD DNS

```powershell
Set-DnsClientServerAddress `
    -InterfaceAlias "Ethernet0" `
    -ServerAddresses "192.168.183.10"

ipconfig /flushdns
```

Domain members must use a DNS server that hosts the AD DNS namespace. Public DNS or the VMware NAT resolver cannot locate AD-specific SRV records.

### Validate domain-controller discovery

```powershell
nltest /dsgetdc:northstar.example.com
```

The result identified `DC01.northstar.example.com` at `192.168.183.10` and included the expected PDC, GC, LDAP, KDC, DNS, time-server, and writable-DC flags.

![Successful domain-controller discovery](../assets/screenshots/03-ad-ds-forest-deployment/03-07-dc-locator-success.png)

## Step 4 - Correct the stale Public network profile

Even after DNS and domain-controller discovery worked, `Get-NetConnectionProfile` initially returned `Public`. Windows Network Location Awareness had classified the connection before domain discovery became healthy and retained that stale state.

Because the VM was being managed from its local VMware console, the adapter could be safely reset:

```powershell
Disable-NetAdapter -Name "Ethernet0" -Confirm:$false
```

After approximately ten seconds:

```powershell
Enable-NetAdapter -Name "Ethernet0" -Confirm:$false
```

Validation:

```powershell
Get-NetConnectionProfile
```

Final result:

```text
Name             : northstar.example.com
NetworkCategory  : DomainAuthenticated
```

![Domain-authenticated network profile](../assets/screenshots/03-ad-ds-forest-deployment/03-08-domain-authenticated-profile.png)

The profile was not manually forced to `Private`. `DomainAuthenticated` is selected automatically after Windows locates and authenticates with a domain controller. It activates the correct Windows Defender Firewall profile for domain communication.

## Recovery case study - why the first promotion was rebuilt

### Symptoms

The first forest was created as `northstar.example`. AD DS services ran, but:

- the forward lookup zone and `_msdcs` zone were absent;
- AD DNS queries returned `DNS name does not exist`;
- DNS event 4013 reported that DNS was waiting for initial AD synchronization;
- `dcdiag /test:DNS` failed connectivity;
- attempts to create the zone with PowerShell and `dnscmd` returned `ERROR_INVALID_NAME 123`.

![First-build DNS diagnostic](../assets/screenshots/03-ad-ds-forest-deployment/03-03-first-build-dns-diagnostic.png)

### Diagnostic reasoning

The investigation confirmed:

- AD DS, DNS, KDC, Netlogon, and NTDS services were running;
- local LDAP and RPC ports were listening;
- the AD naming contexts existed;
- the single domain controller reported no replication partners or replication errors;
- restarting and requesting DNS registration did not create the missing zones.

The role was installed, but the DNS namespace was not usable. Continuing would have produced unreliable domain joins, authentication, and Group Policy.

### Recovery decision

Instead of manually constructing incomplete DNS data, the VM was reverted to:

```text
02 - DC01 Pre-AD DS Configuration
```

The restored state was validated before rebuilding:

- account: `DC01\Administrator`;
- hostname: `DC01`;
- address: `192.168.183.10`;
- AD DS and DNS roles: available rather than installed.

![Snapshot restore validation](../assets/screenshots/03-ad-ds-forest-deployment/03-04-snapshot-restore-validation.png)

AD DS was then installed again and the forest was created as `northstar.example.com`. The expected AD-integrated zones and locator records were created successfully.

### Root-cause statement

The exact internal cause of Windows returning `ERROR_INVALID_NAME 123` for the original namespace was not conclusively proven. The confirmed failure was that the original promotion did not create a usable AD DNS namespace and rejected normal zone-creation attempts. The professional response was to restore a known-good pre-promotion snapshot and rebuild with a conventional multi-label private lab namespace.

This distinction matters: a troubleshooting report should separate verified facts from hypotheses.

## Snapshot strategy

Snapshots are recovery checkpoints, not replacements for backups.

| Snapshot | Purpose |
|---|---|
| `01 - Windows Server 2022 Clean Install` | Return to the clean operating-system baseline |
| `02 - DC01 Pre-AD DS Configuration` | Safely retry role installation or forest promotion |
| `03 - AD DS Forest Healthy` | Completed checkpoint protecting the validated forest before the client domain join |

Never revert a production domain controller casually. VMware snapshots are appropriate here because this is an isolated, single-DC educational lab.

## Interview-ready explanation

> I installed AD DS and its management tools on Windows Server 2022, promoted DC01 as the first domain controller in the `northstar.example.com` forest, and installed AD-integrated DNS and the Global Catalog. I validated the domain, DNS zones, LDAP SRV record, host record, and domain-controller locator results. When the network remained classified as Public, I confirmed DNS and DC discovery first, then reset the VMware network adapter to trigger Network Location Awareness. Windows correctly reclassified the connection as DomainAuthenticated. I also used a pre-promotion snapshot to recover from an earlier DNS-zone creation failure rather than leaving the environment in an unsupported or unreliable state.

## What to remember

Use **R-P-D-V**:

1. **Role** - install AD DS binaries and management tools.
2. **Promote** - create the forest and domain controller.
3. **DNS** - verify zones and locator records; point members to AD DNS.
4. **Validate** - confirm DC discovery, services, firewall profile, and health.

You do not need to memorize every command. Remember the purpose of each test and use PowerShell help when reproducing it:

```powershell
Get-Help Get-DnsServerZone -Examples
Get-Help Resolve-DnsName -Examples
```

## Sources

- [Microsoft Learn: Install Active Directory Domain Services](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/install-active-directory-domain-services--level-100-)
- [Microsoft Learn: Forest and domain functional levels](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/active-directory-functional-levels)
- [Microsoft Learn: DNS and AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/reviewing-dns-concepts)
- [Microsoft Learn: DNS SRV records registered by domain controllers](https://learn.microsoft.com/en-us/troubleshoot/windows-server/networking/verify-srv-dns-records-have-been-created)
- [Microsoft Learn: Domain network-profile detection](https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/domain-joined-machines-cannot-detect-domain-profile)
- [Microsoft Learn: Active Directory naming conventions](https://learn.microsoft.com/en-us/troubleshoot/windows-server/active-directory/naming-conventions-for-computer-domain-site-ou)
- [Microsoft Learn: Virtualized domain-controller architecture](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/virtual-dc/virtualized-domain-controller-architecture)
