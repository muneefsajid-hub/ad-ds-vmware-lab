# Validation Checklist

This file records the tests used to prove that each lab phase works as intended.

| Test ID | Phase | Test | Expected result | Status |
|---|---:|---|---|---|
| VAL-001 | 0 | Verify Windows 11 edition | Windows 11 Pro supports domain joining | Passed |
| VAL-002 | 0 | Inspect server recovery snapshot | `01 - Windows Server 2022 Clean Install` is available | Passed |
| VAL-002A | 0 | Verify host capacity | 4 cores, 8 logical processors, 15.73 GB RAM, and 128.9 GB free storage recorded | Passed |
| VAL-003 | 1 | Start `DC01` | Server reaches the Windows desktop successfully | Passed |
| VAL-003A | 1 | Verify server resources | 2 logical processors, 4 GB RAM, and approximately 60 GB system disk are reported | Passed |
| VAL-003B | 1 | Verify VMware Tools | `VMTools` service reports `Running` | Passed |
| VAL-003C | 1 | Verify Secure Boot | `Confirm-SecureBootUEFI` returns `True` | Passed |
| VAL-003D | 2 | Verify Windows computer name | `hostname` returns `DC01` | Passed |
| VAL-003E | 2 | Verify static addressing | `DC01` uses `192.168.183.10/24` with gateway `192.168.183.2` | Passed |
| VAL-003F | 2 | Verify DNS and HTTPS connectivity | Name resolution succeeds and TCP 443 test returns `True` | Passed |
| VAL-003G | 2 | Verify time configuration | Eastern time zone and Windows Time synchronization are confirmed | Passed |
| VAL-003H | 2 | Verify operating-system updates | Required Windows updates are installed and configuration persists after restart | Passed |
| VAL-004 | 2 | Test server gateway and Internet reachability | Gateway responds and HTTPS connection succeeds | Passed |
| VAL-005 | 3 | Query AD DS DNS records | `DC01` host record and `_ldap._tcp.dc._msdcs` SRV record resolve | Passed |
| VAL-005A | 3 | Verify AD-integrated zones | `northstar.example.com` and `_msdcs.northstar.example.com` exist and are AD-integrated | Passed |
| VAL-005B | 3 | Verify domain identity | DNS root, NetBIOS name, functional level, and PDC emulator match the design | Passed |
| VAL-005C | 3 | Verify DC discovery | `nltest /dsgetdc:northstar.example.com` locates `DC01` with required service flags | Passed |
| VAL-005D | 3 | Verify network profile | `Get-NetConnectionProfile` reports `DomainAuthenticated` | Passed |
| VAL-005E | 3 | Create healthy-forest recovery checkpoint | Snapshot `03 - AD DS Forest Healthy` exists before the client domain join | Passed |
| VAL-006 | 3 | Run final domain-controller health checks | DNS, advertising, SYSVOL, and Netlogon tests return acceptable results | Pending |
| VAL-007 | 4 | Join `CLIENT01` to the domain | Domain join succeeds and restart is requested | Pending |
| VAL-008 | 4 | Sign in as a domain user | Domain authentication succeeds | Pending |
| VAL-009 | 5 | Test group-based access | Authorized group succeeds; unauthorized identity is denied | Pending |
| VAL-010 | 6 | Apply a test GPO | Target client receives intended policy | Pending |
| VAL-011 | 8 | Test directory replication | Change appears on the second domain controller | Pending |
